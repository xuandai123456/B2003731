<?php
$servername = "localhost";
$username = "root";
$password ="";
$dbname ="qlsv";

//create connection
$conn = new mysqli ($servername, $username, $password, $dbname);

//check connection
if ($conn->connect_error){
    //hien thi loi neu ket noi khong duoc
    die("Connection failed: " . $conn->connect_error);
}
//sql tu create table
$sql = "create table student(
    id int(6) UNSIGNED AUTO_INCREMENT primary key,
    fullname varchar(50) not null,
    email varchar(50),
    Birthday date,
    reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE
    CURRENT_TIMESTAMP
    )";

    if($conn-> query($sql) == TRUE){
        echo "table student created successfully";
    }else{
        echo "error creating table: " . $conn->error;
    }

    $conn->close();
?>