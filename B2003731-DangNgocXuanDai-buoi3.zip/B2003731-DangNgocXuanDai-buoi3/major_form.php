<!DOCTYPE HTML>
<html>  
<body>

<form action="major_add.php" method="post">
ID: <input type="text" name="id"><br>
Major: <input type="text" name="major"><br>

<input type="submit">
</form>

</body>
</html>
