<?php
$servername = "localhost";
$username = "root";
$password ="";
$dbname ="qlsv";

//create connection
$conn = new mysqli ($servername, $username, $password, $dbname);

//check connection
if ($conn->connect_error){
    //hien thi loi neu ket noi khong duoc
    die("Connection failed: " . $conn->connect_error);
}
//sql tu create table
$sql = "create table major(
    id int(6) UNSIGNED AUTO_INCREMENT primary key,
    name_major varchar(50) not null
    )";

    if($conn-> query($sql) == TRUE){
        echo "table student created successfully";
    }else{
        echo "error creating table: " . $conn->error;
    }

    $conn->close();
?>