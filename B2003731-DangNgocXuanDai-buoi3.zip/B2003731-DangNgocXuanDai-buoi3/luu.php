<?php
$servername = "localhost";
$username = "root";
$password ="";
$dbname ="qlsv";

//create connection
$conn = new mysqli ($servername, $username, $password, $dbname);

//check connection
if ($conn->connect_error){
    //hien thi loi neu ket noi khong duoc
    die("Connection failed: " . $conn->connect_error);
}

$date = date_create($_POST["birth"]);

$sql = "INSERT into student (fullname, email, birthday,major_id) Values (' ".$_POST["name"] ."', '".$_POST["email"] ."',
' ".$date->format('y-m-d') . "', '".$_POST["major"] ."')";

if($conn->query($sql) == TRUE) {
    echo "them sinh vien thanh cong";
    //neu thuc hien thanh cong se cho di chuyen den <taidulieu_bang.php
    header('location: taidulieu_bang1.php');
}else{
    echo "error: " .$sql . "<br>" . $conn->error;
}
$conn->close();
?>