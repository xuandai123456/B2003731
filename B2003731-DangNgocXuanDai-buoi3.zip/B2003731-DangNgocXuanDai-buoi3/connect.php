<?php
$servername = "localhost";
$username = "root";
$password ="";

//create connection
$conn = new mysqli ($servername, $username, $password);

//check connection
if ($conn->connect_error){
    //hien thi loi neu ket noi khong duoc
    die("Connection failed: " . $conn->connect_error);
}
//neu ket noi thanh cong
echo "Connected successfully";
?>
